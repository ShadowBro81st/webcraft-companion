@echo off
title WebCraft Companion
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 goto nonode
node webcraft-companion.cjs  %*
pause
exit /b

:nonode
echo WebCraft Companion needs Node.js (free, one-time install).
echo.
choice /M "Install Node.js now"
if errorlevel 2 goto manual
winget install -e --id OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements
if errorlevel 1 goto manual
echo.
echo Node.js is installed! Close this window and double-click this file again.
pause
exit /b

:manual
echo.
echo Opening nodejs.org - download the LTS version, install it, then run this file again.
start https://nodejs.org/
pause
