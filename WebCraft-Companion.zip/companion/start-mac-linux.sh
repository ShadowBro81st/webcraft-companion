#!/bin/sh
# Mac / Linux: needs Node.js 18+ (https://nodejs.org)
cd "$(dirname "$0")"
node webcraft-companion.cjs "$@"
