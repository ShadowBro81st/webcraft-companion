@echo off
title Fix localhost for Minecraft
:: Some Windows builds of Minecraft are sandboxed and can't reach apps on the same PC via
:: "localhost". This adds Minecraft to Windows' loopback exemption list (Microsoft's own tool).
:: It's safe and can be undone with:  CheckNetIsolation LoopbackExempt -c
net session >nul 2>&1
if errorlevel 1 (
  echo Please right-click this file and choose "Run as administrator".
  pause
  exit /b
)
echo Allowing Minecraft to connect to apps on this PC...
CheckNetIsolation LoopbackExempt -a -n="Microsoft.MinecraftUWP_8wekyb3d8bbwe"
powershell -NoProfile -Command "Get-AppxPackage *minecraft* | ForEach-Object { Write-Host ('  ' + $_.PackageFamilyName); CheckNetIsolation LoopbackExempt -a -n=\"$($_.PackageFamilyName)\" | Out-Null }"
echo.
echo Done! Fully close Minecraft, reopen it, start the companion, and try /connect localhost:8765 again.
pause
