# WebCraft Browser v1.7 — real internet inside Minecraft Bedrock

> **Upgrading from an earlier WebCraft? Do this first, or the old pack can stop everything working:**
> 1. In Minecraft go to **Settings → Storage → Resource Packs / Behavior Packs** and **delete every pack named WebCraft**.
> 2. Edit your world → **Behavior Packs** and **Resource Packs**: remove any old WebCraft packs.
> 3. Import the new **WebCraft.mcaddon**, then activate **WebCraft Browser v1.7 [BP]** in the world.
> 4. Use the new **WebCraft-Companion.zip** too (replace the old companion folder).

Craft a **Web Tablet**, use it, and browse real websites in-game: search the web, type addresses, follow links, bookmark pages, keep history, find text, and share pages to chat.

**No dedicated server needed.** WebCraft now works in **normal worlds** through Minecraft's built-in `/connect` WebSocket feature and a small companion app on your PC. No Beta APIs are needed either.

Pages show as clean, coloured text with numbered links (like `Creeper[3]`), so think of it as a text-mode browser built into Minecraft's menus. Wikipedia, wikis, news, forums, docs and search results work great. Videos, images and JavaScript-only sites can't display.

---

## Quick start (normal worlds, about 3 minutes)

**1. Install the add-on.** Double-click **WebCraft.mcaddon** and Minecraft imports it.

**2. Set up a world.** Create a world, or edit an existing one:
- **Behavior Packs**: activate **WebCraft Browser v1.7 [BP]**
- **Cheats**: **ON** (needed so the companion can talk to the add-on; note this turns off achievements for that world)

**3. Start the companion.** On your Windows PC, unzip **WebCraft-Companion.zip** and double-click **Start WebCraft Companion.bat**.
- The first time, if you don't have Node.js (the free engine it runs on), it offers to install it for you. Press **Y**, wait for the install, then double-click the launcher again.
- If Windows shows "Windows protected your PC", choose **More info → Run anyway**. Allow it through the firewall if asked.
- Keep the window open while you play.

**4. Connect.** In your Minecraft world, type in chat:

```
/connect localhost:8765
```

The companion window should show:

```
Minecraft connected! Testing the link…
Link OK (…). Checking for the add-on…
✓ WebCraft add-on detected (v1.7.0).
```

When you join the world you'll also see **"[WebCraft] v1.7.0 loaded"** in chat. If you don't, the behavior pack isn't running; see Troubleshooting. Reconnect with `/connect` each time you join a world.

**5. Browse!** Craft the tablet (or `/give @s webcraft:web_tablet`) and use it.

```
 Iron  Iron  Iron
 Iron  Glass Iron        Glass = glass pane
 Iron  Red.  Iron        Red.  = redstone
```

### Playing on a phone, tablet or console?
Run the companion on a PC connected to the **same Wi-Fi**. The companion window shows a line like `/connect 192.168.1.20:8765`; type that in Minecraft on your device instead of `localhost`.

### Mac / Linux
Install Node.js 18+ from nodejs.org, then run `start-mac-linux.sh`.

---

## Using the browser

- **Search the web**: DuckDuckGo by default (switch to DuckDuckGo Lite, Mojeek or Wikipedia in Settings)
- **Enter address**: a URL, or anything else to search it
- **Next / Previous page**: long pages split into chunks; a % shows in the action bar while big pages load
- **Links on this page** / **All links**: tap a link to see where it goes, then open it
- **Find in page / jump**, **Back / Forward**, **Bookmarks**, **History** (saved per player)
- **Share to chat**: everyone sees the link, and others can tap **Open last shared link**
- **Quick links**: Wikipedia, NPR text, CNN Lite, Hacker News, Minecraft Wiki, weather

**Chat shortcuts** (while the companion is connected):
- `!web minecraft.wiki`: open a site
- `!search best redstone farms`: search
- `!pic <picture address>`: build a picture

### The WebCraft PC (new in 1.4)

Place a **WebCraft PC** block, a little monitor with a keyboard that glows softly, and **right-click it**. The browser opens in its own **computer-style window**, with a monitor frame, title bar, an **address bar showing the site you're on**, a dark page area and a sidebar of buttons. It remembers the page you were on, so walking up and clicking it carries on where you left off.

**Craft it** with a Web Tablet in the middle:

```
 Iron   Glass  Iron
 Iron   Tablet Iron
 Iron   Redstone-block  Iron
```

or `/give @s webcraft:computer`. The handheld tablet still works and keeps the normal Minecraft menus.

Typing boxes (search, address, settings) still use Minecraft's normal pop-up, because those can't be restyled safely.

### Pictures (shown inside the window)

On the **WebCraft PC**, pictures appear **right inside the page**, where they sit in the article, drawn in 4,096 colours.

**Picture quality** (Settings → *Picture quality*):

| Setting | In pages | Picture viewer | Notes |
|---|---|---|---|
| Normal | 52 px wide | 70 px | fastest |
| **Sharp** (default) | 78 px | 104 px | best balance |
| Ultra (experimental) | 116 px | 156 px | sharpest; uses very tiny pixels; if pictures look wrong or menus lag, go back to Sharp | Pages with pictures take a second longer to open while they download.

- **Pictures on this page** opens a picture in a **bigger viewer** inside the PC window. This works from the tablet too.
- In the page text, pictures are marked like `[pic 2: A creeper]`.
- Turn inline pictures off in **Settings** → *Show pictures inside pages* if you want pages to load faster.
- Want it bigger in your world? The viewer has an optional **Build as pixel art in the world** button (only fills empty air, removable from **My pictures**).
- Direct picture links work too, and so does `!pic <address>` in chat.
- PNG, JPEG, GIF and BMP pictures work. WebP/AVIF/SVG pictures can't be shown yet (most sites still send a JPEG or PNG when asked).

**Commands** (great for command blocks):
- `/scriptevent webcraft:open` (home), `/scriptevent webcraft:open <address>`, `/scriptevent webcraft:search <words>`

---

## Troubleshooting

| Problem | Fix |
|---|---|
| The PC opens a **normal grey menu** instead of the computer window | The resource pack isn't active in the world. Activate **WebCraft Browser v1.7 [RP]** in Resource Packs. |
| **Any menus look broken** after adding v1.4 | Turn the WebCraft resource pack off (everything still works, just without the PC window and custom icons) and send a screenshot to whoever is helping you. |
| Pictures show as **empty boxes or odd symbols** in the window | The resource pack isn't active (it holds the picture colours). Activate **WebCraft Browser v1.7 [RP]**. |
| Pixel-art pictures show as **purple/black checkerboard** blocks | The resource pack isn't active. Activate **WebCraft Browser v1.7 [RP]** in the world's Resource Packs. |
| **Not sure if the add-on is loaded?** | Type `/scriptevent webcraft:status` in chat. If it's loaded it replies *"Add-on v1.7.0 is running"*. No reply means the pack isn't active in this world (or cheats are off). |
| **In-game `/connect` says it failed** | Look at the companion window. **If no new lines appear** after you type `/connect`, Minecraft isn't reaching the companion: try `/connect 127.0.0.1:8765`. If that fails too, right-click **Fix localhost (run as admin).bat** → *Run as administrator*, restart Minecraft, and try again. **If lines do appear** (like *"Minecraft is connecting…"* followed by a ✗), send those lines to whoever is helping you, because they show exactly which step failed. |
| *"Require Encrypted Websockets"* can't be turned off | That's fine, you don't need to. The normal launcher handles encryption. That setting only matters for the troubleshooting launcher. |
| Companion says **"The WebCraft add-on isn't responding"**, or you never see *"[WebCraft] v1.7.0 loaded"* when joining | The behavior pack isn't running. Follow the **Upgrading** steps at the top: delete all old WebCraft packs in Settings → Storage, re-import v1.2, and activate **WebCraft Browser v1.7 [BP]** in the world. Your game must be version 1.21.90 or newer. |
| Companion says **"Minecraft refused commands"** | Turn **cheats on** for the world, then `/connect` again. |
| Companion says **"Minecraft dropped the connection while receiving…"** | Just type `/connect` again. The companion remembers to use smaller messages from now on (saved in `.webcraft-companion.json` in your user folder; delete it to reset). |
| Companion says **"The add-on hasn't answered yet"** | Common on the **first load of a new or just-edited world**: Minecraft sometimes only starts add-on scripts after a rejoin. Leave the world, join again (and `/connect` again if needed). The companion notices automatically and says **"✓ The add-on is answering now"**. |
| `/connect` says it couldn't connect | Is the companion window open? Allow it through Windows Firewall. On another device, use the PC's address shown in the companion, not `localhost`. |
| Tablet says "Companion not connected" | Type `/connect localhost:8765` again (you must reconnect after rejoining a world). |
| Connected, but pages never load | Close the companion and use **Start (no encryption - troubleshooting).bat**. Then in Minecraft go to **Settings → General** and turn off **Require Encrypted Websockets**, and `/connect` again. |
| A search engine stops working | Some sites block automated visitors. Switch engines in **Settings**. |

**Where `/connect` works:** single-player worlds and worlds you host for friends (LAN/online friends). Realms and public servers don't allow `/connect`; for a dedicated server use the BDS Edition below.

---

## Safety

- The companion **only** fetches pages for the WebCraft add-on and blocks addresses on your home network (router, other PCs) by default.
- Websites see your PC's internet address when you browse, just like a normal browser.
- Admins: `/tag @s add webcraft_admin`, then the tablet shows **Server admin**, where you can turn browsing off, restrict it to players tagged `webcraft`, or block domains.

---

## BDS Edition (for Bedrock Dedicated Server owners)

If you run a dedicated server, **WebCraft-BDS-Edition.mcaddon** fetches pages directly from the server with no companion needed:
1. Apply **WebCraft Browser [BDS Edition]** to the world and enable the **Beta APIs** experiment.
2. Copy the folder inside `bds_server_config` into your server's `config` folder (it enables the `@minecraft/server-net` module).
3. Don't apply both editions to the same world.

---

## Companion options

`node webcraft-companion.cjs [--port 8765] [--no-encryption] [--allow-private] [--debug]` (or add the options to the launcher's `node` line)

- `--port`: use a different port (then `/connect localhost:<port>`)
- `--no-encryption`: for Education Edition or troubleshooting
- `--allow-private`: allow local network addresses (e.g. your own dev server)
- `--debug`: verbose logging

## How it works (for the curious)

The add-on writes a page request onto your player as tags. The companion (connected through `/connect`) reads them with `tag @a list`, fetches and renders the page, and streams the result back through `/scriptevent` in base64 chunks. It auto-detects how long a command Minecraft accepts and shrinks chunks if the game ever rejects one.
